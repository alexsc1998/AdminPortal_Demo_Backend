export const ERRORS = {
  NOT_FOUND: 'not found',
  UPDATE_FAILED: 'updated failed',
  DELETE_FAILED: 'delete failed',
  PWD_UPDATE_LIMIT: ' pwd update limit',
  OLD_PWD_UPDATE: 'old pwd update',
  INVALID_ID: 'invalid id',
} as const;
